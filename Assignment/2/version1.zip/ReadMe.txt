To run the program, open MATLAB, change to the directory containing the script, and execute the following command in MATLAB's command window:
mySecondAssignment('images\img.png', 3.5);

Note:
--> You can change img path and multifact
--> in images folder sample images are present, and outputs at each step in saving in current directory