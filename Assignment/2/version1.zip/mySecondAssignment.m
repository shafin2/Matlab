% highboost masking is a technique used to enhance the edges in an image, its process is as follows:
% 1. Apply an averaging filter to the image to get a blurred image
% 2. Subtract the blurred image from the original image to get the edges
% 3. Multiply the edges with a factor to enhance them
% 4. Add the enhanced edges to the original image to get the final image
% souce: ch 4 Image Enhancement, 4.3.3 sharpening filters, Digital Image Processing, Gonzalez, Woodss
function mySecondAssignment(filename, multifact)
  % import convultion/average code 
  addpath('../../GenericCode/')

  % Read the input image
  img = double(rgb2gray(imread(filename)));

  % Display the original image
  figure, imshow(uint8(img));
  title('Original Image');
  % save the original image
  imwrite(uint8(img), 'original_image.jpeg');

  % make averaging filter
  filter = (1/9)*ones(3,3);
  % apply averaging filter using our convolution code to get blur image
  blur_img = my_convolution(img,filter);
  % Display the blurred image
  figure, imshow(uint8(blur_img));
  title('Blurred Image');
  % save the blurred image
  imwrite(uint8(blur_img), 'blurred_image.jpeg');
  
  % get edges by subtracting blur_img from original
  edges = img - blur_img;
  % Display the edges
  figure, imshow(uint8(edges));
  title('Edges');
  % save the edges
  imwrite(uint8(edges), 'edges_image.jpeg');

  % Multiply edges with multifact to get more enhanced edges
  enhanced_edges= multifact*edges;
  % Display the enhanced_edges
  figure, imshow(uint8(enhanced_edges));
  title('Enhanced Edges');
  % save the enhanced_edges
  imwrite(uint8(enhanced_edges), 'enhanced_edges_image.jpeg');

  % Get high-boost filter img
  highboost_img = img + enhanced_edges;
  % Display the final img
  figure, imshow(uint8(highboost_img));
  title('Output image');
  % save the final image
  imwrite(uint8(highboost_img), 'highboost_masked_image.bmp');
end